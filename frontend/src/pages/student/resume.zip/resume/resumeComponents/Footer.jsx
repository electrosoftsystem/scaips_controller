import React from "react";

function Footer() {
  return (
    <footer className="w-full max-w-4xl mx-auto py-4 px-4 sm:px-6 md:px-8">
      <div className="flex items-center justify-end gap-2 text-gray-500 text-sm">
        <img
          src="/titlelogo.png"
          alt="SCAIPS Logo"
          width={28}
          height={20}
          className="object-contain opacity-80"
        />
        <span className="font-semibold text-gray-700">www.scaips.in</span>
      </div>
    </footer>
  );
}

export default Footer;
