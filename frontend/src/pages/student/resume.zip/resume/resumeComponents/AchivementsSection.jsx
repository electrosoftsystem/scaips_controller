import { CalendarDays, Trophy } from "lucide-react";
import React from "react";

function AchievementsSection({ achivements = [], isDarkMode = true }) {
  const getGridClasses = () => {
    if (!achivements || achivements.length === 0) return "";
    if (achivements.length === 1) return "max-w-3xl mx-auto";
    if (achivements.length === 2) return "grid md:grid-cols-2 gap-4 max-w-5xl mx-auto";
    return "grid md:grid-cols-2 lg:grid-cols-3 gap-4";
  };

  const textHeading = isDarkMode ? "text-white" : "text-gray-900";

  return (
    <section
      id="achievements"
      className={`py-6 px-8 ${isDarkMode ? "bg-gray-900" : "bg-white"}`}
    >
      <div className="max-w-4xl mx-auto">
        {/* ====== SECTION TITLE ====== */}
        <hr
          className={`border-t-2 mb-2 ${
            isDarkMode ? "border-white/40" : "border-gray-400"
          }`}
        />
        <h2 className={`text-2xl font-bold mb-4 ${textHeading}`}>
          Achievements
        </h2>

        {/* ====== ACHIEVEMENTS GRID ====== */}
        {achivements.length > 0 ? (
          <div className={getGridClasses()}>
            {achivements.map((ach, idx) => (
              <div key={idx}>
                <div
                  className={`p-4 rounded border ${
                    isDarkMode
                      ? "bg-white/5 border-white/10"
                      : "bg-white border-gray-200"
                  }`}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center">
                      <Trophy className="text-white" size={16} />
                    </div>
                    <h3
                      className={`text-sm font-semibold ${
                        isDarkMode ? "text-white" : "text-gray-800"
                      }`}
                    >
                      {ach.title || "Untitled Achievement"}
                    </h3>
                  </div>

                  <p
                    className={`text-xs mb-2 ${
                      isDarkMode ? "text-gray-300" : "text-gray-600"
                    }`}
                  >
                    {ach.description || "No description available."}
                  </p>

                  <div
                    className={`flex justify-between text-xs pt-2 border-t ${
                      isDarkMode
                        ? "border-gray-700 text-gray-400"
                        : "border-gray-200 text-gray-500"
                    }`}
                  >
                    <span className="flex items-center gap-1">
                      <CalendarDays size={14} />
                      {ach.date
                        ? new Date(ach.date).toLocaleDateString("en-IN", {
                            day: "2-digit",
                            month: "short",
                            year: "numeric",
                          })
                        : "Date N/A"}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full font-semibold text-[10px] border ${
                        isDarkMode
                          ? "border-purple-400/40 text-purple-300 bg-purple-500/10"
                          : "border-purple-200 text-purple-700 bg-purple-100"
                      }`}
                    >
                      {ach.tag || "General"}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <div
              className={`w-16 h-16 mx-auto mb-2 flex items-center justify-center rounded-full border ${
                isDarkMode
                  ? "border-gray-700 bg-white/5"
                  : "border-gray-300 bg-gray-100"
              }`}
            >
              <Trophy
                size={28}
                className={`${isDarkMode ? "text-gray-500" : "text-gray-400"}`}
              />
            </div>
            <p
              className={`${
                isDarkMode ? "text-gray-400" : "text-gray-600"
              } text-sm`}
            >
              No achievements added yet.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

export default AchievementsSection;
